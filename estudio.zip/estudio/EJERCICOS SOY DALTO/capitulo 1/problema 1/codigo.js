class Telefonos {
	constructor(color,peso,resPantalla,resCamara,ram){
	  this.color = color;
	  this.peso = peso;
	  this.resPantalla = resPantalla;
	  this.resCamara = resCamara;
	  this.ram = ram;
	}
  }
  
  const samsungA20 = new Telefonos("negro","120g","720p","3mpx","2gb")
  const iphone6s = new Telefonos("negro","100g","1080","6mpx","4gb")
  const motorolaX = new Telefonos("gris","250","1920","15mpx","6gb")
  
  function mostrarTelefonos(){
	alert("a continuacion te mostrare los modelos disponibles");
	const eleccion = prompt("1-samsungA20 ","2-iphone 6S", "3-motorola")
	
	if(eleccion ==1 ){
	  document.write(samsungA20)
	   } 
  }
  
  mostrarTelefonos()
  