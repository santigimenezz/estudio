class persona {
	constructor (nombre,apellido){
	  nombre  this.nombre;
	  apellido  this.apellido
	}
  }
 
 const santiago = new persona("santi", "gimenez");
 console.log(santiago)